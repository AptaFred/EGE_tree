You can input your raw data into this excel file, then, following this 10 steps described below and using the model file (EGE_Tree_model.cys), you will obtain an EGE tree in Cytoscape (http://cytoscape.org/)

IMPORTANT
***************************************************************************************************************************

This table is limited to 100 sequences and to 15 rounds of selection.
Backup the original EGE_Tree_method.xls before modification
Never use the copy paste function but use copy and paste value
Be sure to replace "." per "," or the inverse depending on the version of your excel in order to have numbers
Never use the sign ">" in the name of the sequence
We use Cytoscape 3.2.1 version, with any other version of cytoscape the style can be lost

***************************************************************************************************************************

I	Input your data : 

		- Copy the data you wish to analyse and Paste it into the table of the sheet "data" in the following manner: 
		1) the name of the sequence (it's better to name each sequence by a mutation related to a seed sequence of interest (for example the most abundant sequence of the last round), 2)  the sequence and 3) the frequency of the sequence in the library at each round

II	Frequency Treshold :

		- In the sheet "Threshold", define a frequency threshold which should represent an undeniable enrichment in the population (e. g. 0.01% for 500,000 reads.) 
		Be advise that the calculation are meant for 100 sequences max (You can contact the aptamer platform of MIRCen at CRC-MIRCEN@cea.fr if you need more, however based on our experience it is better to focuse on the 100 most amplified sequences of the SELEX). 
  		- Use the filter in the column "Filter" to select only the sequences that are higher than the threshold (by removing "not enough" from the column).
   		- Copy the values in the column "name" "sequences" and the frequencies at each round, and paste everything in the sheet "frequencies". 

III	Creaste a fasta file of the obtained sequences :

 		- Create a new excel file and save it in .csv format with the name "fasta_sequence.csv". 
		- Copy paste in this excel file the value of the columns ">", "Name" and "Sequence" (of the sheet Treshold). Save the file and close it. 
		- Open the file fasta_sequence.csv with word
		- replace every >; by >
		- replace every ; by ^p (it replaces every ; with line breaks)
		- replace ^p^p by ^p repeatedly until empty line breaks are deleted. 
		- Save in txt format as fasta_sequence.txt

IV	Identity Matrix :	

		- Use the file "fasta_sequence.txt" to create a Percent Identity Matrix in Clustal Omega directly on the website https://www.ebi.ac.uk/Tools/msa/clustalo/ , alternatively you can use other distance matrix calculated by other multiple alignment programs. 
		- Step 1 select the chemistry (ADN, ARN of protein), upload your sequences on the website, in output format (more option) chose order as input click the submit button
		- On the result page, go to the "result Summary" tab and save the file "Percent Identity Matrix".
		- Convert the title of file that is in ".pim" in ".txt" format                                          
		- Open  excel and import this .txt file (be sure to search "every files" to find .txt files).
		- In the  import options, choose "delimited", click next, put only space as a delimiter then Click done.
		- Delete the two first columns (one empty the other with numbers in it) and the 6 first rows that doesn't contain any values.
		- Copy this matrix (be sure to change the "." in "," if your excel requires it  ) 
		- Paste it in the sheet "Identity matrix" of the excel File "EGE_Tree_method.xls" 

The link between sequences will be automatically calculated in the sheet "paternity_link" 
and the percentage of the sequences in the family at each round will be automatically calculated in the sheet "Percentage_in_Family". 

V 	Ranking the frequencies (optional):

		- in the sheet "frequencies" rank the values of each columns in an ascending order, from the last round to the first round. 
		This is not mandatory but it allows to obtain a tree that is easier to interpret. 
		Similarly, if an ancestor is clearly identified, it may be important to put it first in the sheet "frequencies".

VI	Obtaining the link file :

		- Copy all the values from the sheet "paternity_link" and paste it in a new excel file  
		- Save it in .csv format (e. g. with the name "linkFamilyX.csv"). and close it.
 		- Open the file link.csv with word and replace all ; by ^p (it replaces the ; with line breaks). 
		- Then replace all ^p^p by ^p repeatedly until empty line breaks are deleted. 
		- Save it in txt format as linkFamilyX.txt

VII 	Obtaining the Percent file :

		- Copy all the values of the table found in the sheet "Percentage_in_Family" and paste it in a new excel file 
		- Save it in .csv format (e. g. with the name "percentFamilyX.csv") and close it.
		- Open the file percent.csv with word and replace all ; by ^p (it replaces the ; with line breaks). 
		- Then replace all ^p^p by ^p repeatedly until empty line breaks are deleted (the first line in the file is an empty line, leave it untouched).
		-If your numbers have "," (ex: 2,2) replace every , per . (ex 2.2) 
		- Save it in .txt format as percentFamilyX.txt


VIII	Cytoscape : import link.txt 
	 
		- Open the software Cytoscape (3.2.1 version) 
		- Open the "EGE_tree_model.cys" 
		- In the menu : File/Import/Network select the file "linkfamilyX.txt". 
		- Select "advanced" import option (Show text file import option) and make sure only "other" is selected, with the value > (it will create 2 columns)
		- Verify that "transfer first line as column names" is not selected. 
		- Select in "interaction Definition" Column 1 as Source node column; and Column 2 as Target interaction. 
		- Finally Clik on the OK button. (the Network is now created)

IX	Cytoscape : import percent.txt

		- In the menu File/Import/Table select the File PercentageFamilyX.txt
		- s�lect a network collection that correspond to your link (ex: linkFamilyX.txt)  
		- Select "advanced" import option (Show text file import option). make sure only "other" is selected, with the value > (it will create 2 columns) 
		- verify that "transfer first line as column names" is not selected. 
		- Finally Clik on the OK button. (The size and the color of the nodes in the network should correspond to their size in the family at one round.)
		- it is sometimes necessary to zoom to see the name of the s�quence
		
X	Cytoscape : the Layout

		- Select in the menu Layout/Yfiles Layouts/Hierarchic (the tree should be created).
		- In the menu Layout/Yfiles choose Layouts/rotate -90 to see the name of the sequences in right
		

Of course, several other aspect of the EGE tree can be done using the different tools of Cytoscape.




Common problem: the numbers have "." instead of "," or the inverse depending on the version of your excel
For Cytoscape use always �.�
The name of the sequence are not the same between the sheets "Identity_matrix" and "frequencies"
                                                          
